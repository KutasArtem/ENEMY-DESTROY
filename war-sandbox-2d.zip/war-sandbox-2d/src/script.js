const canvas = document.getElementById('radar-map');
const ctx = canvas.getContext('2d');
const levelText = document.getElementById('level');
const ammoText = document.getElementById('ammo');
const livesText = document.getElementById('lives');
const restartButton = document.getElementById('restart-button');
const sandboxToggleButton = document.getElementById('sandbox-toggle');

const mapImage = new Image();
mapImage.src = 'https://upload.wikimedia.org/wikipedia/commons/4/44/Ukraine_map.svg'; // Карта Украины в векторном формате

let shaheds = [];
let rockets = [];
let level = 1;
let ammo = 20; // Для обычного режима
let lives = 3;
let gameOver = false;
let isSandboxMode = false;

let mouseX = 0, mouseY = 0;

// Карта и объекты
mapImage.onload = () => {
    console.log("Карта загружена!");
    ctx.drawImage(mapImage, 0, 0, canvas.width, canvas.height);
    animate();
};

// Система дронов
function createShahed() {
    shaheds.push({
        x: Math.random() * canvas.width,
        y: -20,
        speed: 1 + level * 0.2, // Увеличение скорости на каждом уровне
        size: 10,
    });
}

// Движение дронов
function moveShaheds() {
    shaheds.forEach((shahed, index) => {
        shahed.y += shahed.speed;

        // Если дрон выходит за пределы, удалить его
        if (shahed.y > canvas.height) {
            shaheds.splice(index, 1);
            if (!isSandboxMode) {
                lives--;
                livesText.textContent = lives;
            }
        }
    });
}

// Стрельба ракетами
function createRocket() {
    if (isSandboxMode || ammo > 0) {
        rockets.push({
            x: mouseX,
            y: canvas.height - 30,
            speed: 5,
            size: 5,
            color: 'yellow',
        });
        if (!isSandboxMode) {
            ammo--;
            ammoText.textContent = ammo;
        }
    }
}

// Движение ракет
function moveRockets() {
    rockets.forEach((rocket, index) => {
        rocket.y -= rocket.speed;

        if (rocket.y < 0) rockets.splice(index, 1); // Удаление ракеты, если она выходит за пределы экрана
    });
}

// Проверка столкновений
function checkCollisions() {
    rockets.forEach((rocket, rIndex) => {
        shaheds.forEach((shahed, sIndex) => {
            const dx = rocket.x - shahed.x;
            const dy = rocket.y - shahed.y;
            const distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < rocket.size + shahed.size) {
                shaheds.splice(sIndex, 1);
                rockets.splice(rIndex, 1);
            }
        });
    });
}

// Анимация
function animate() {
    if (gameOver) return;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(mapImage, 0, 0, canvas.width, canvas.height); // Перерисовка карты

    moveShaheds();
    moveRockets();
    checkCollisions();

    // Рисуем дронов
    shaheds.forEach(shahed => {
        ctx.fillStyle = 'red'; // Дроны красные
        ctx.beginPath();
        ctx.arc(shahed.x, shahed.y, shahed.size, 0, Math.PI * 2);
        ctx.fill();
    });

    // Рисуем ракеты
    rockets.forEach(rocket => {
        ctx.fillStyle = rocket.color;
        ctx.beginPath();
        ctx.arc(rocket.x, rocket.y, rocket.size, 0, Math.PI * 2);
        ctx.fill();
    });

    // Рисуем игрока (синий круг)
    ctx.fillStyle = 'blue';
    ctx.beginPath();
    ctx.arc(mouseX, mouseY, 15, 0, Math.PI * 2); // Размер игрока
    ctx.fill();

    if (shaheds.length < level * 5) {
        createShahed();
    }

    if (lives <= 0 && !isSandboxMode) {
        gameOver = true;
        restartButton.style.display = 'block';
    }

    requestAnimationFrame(animate);
}

// Обработчик для мыши
canvas.addEventListener('mousemove', (event) => {
    const rect = canvas.getBoundingClientRect();
    mouseX = event.clientX - rect.left;
    mouseY = event.clientY - rect.top;
});

// Обработчик для клавиши F (выстрел)
document.addEventListener('keydown', (event) => {
    if (event.key === 'f') {
        createRocket();
    }
});

// Обработчик для кнопки перезапуска игры
restartButton.addEventListener('click', () => {
    level = 1;
    ammo = 20; // В обычном режиме патроны восстанавливаются
    lives = 3;
    shaheds = [];
    rockets = [];
    gameOver = false;
    levelText.textContent = level;
    ammoText.textContent = ammo;
    livesText.textContent = lives;
    restartButton.style.display = 'none';
    animate();
});

// Переключение режима песочницы
sandboxToggleButton.addEventListener('click', () => {
    isSandboxMode = !isSandboxMode;
    if (isSandboxMode) {
        sandboxToggleButton.textContent = 'Переключить на обычный режим';
        ammoText.textContent = '∞';
        livesText.textContent = '∞';
    } else {
        sandboxToggleButton.textContent = 'Переключить на режим песочницы';
        ammo = 20;
        lives = 3;
        ammoText.textContent = ammo;
        livesText.textContent = lives;
    }
});

// Увеличение уровня
setInterval(() => {
    if (shaheds.length === 0 && !gameOver && !isSandboxMode) {
        level++;
        levelText.textContent = level;
        createShahed();
    }
}, 10000);
