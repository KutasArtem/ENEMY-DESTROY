# WAR SANDBOX 2D

A Pen created on CodePen.io. Original URL: [https://codepen.io/artem-kutas/pen/jOgvzNp](https://codepen.io/artem-kutas/pen/jOgvzNp).

H - Controls
S - Game mode
F - Fire